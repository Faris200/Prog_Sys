﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kitchen.View
{
    class Movable
    {
        int PosX
        {
            set;
            get;
        }

        int PosY
        {
            set;
            get;
        }

        /*public ElementsType IdElements
        {
            get;
            set;
        }


        public Movable(int posX, int posY, ElementsType IdElements)
        {
            PosX = posX;
            PosY = posY;
            this.IdElements = IdElements;
        }
        ELEMENTSTYPE C'EST LE INT DANS LA BDD QUI CARACTERISE L'OBJET
    */


    }
}
