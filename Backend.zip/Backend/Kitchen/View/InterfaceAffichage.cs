﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salle.View
{
    public interface InterfaceAffichage
    {
        void afficherLine(string str);
        void afficher(string str);
    }
}
