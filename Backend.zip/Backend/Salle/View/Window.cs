﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kitchen.View
{
    class Window
    {



//        public void window();

//        public void UpdateMap(char DisplayMap);
    }
}
